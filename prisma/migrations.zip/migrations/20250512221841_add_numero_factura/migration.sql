-- AlterTable
ALTER TABLE `solicitacaoautorizacao` ADD COLUMN `numeroFactura` VARCHAR(191) NULL;
