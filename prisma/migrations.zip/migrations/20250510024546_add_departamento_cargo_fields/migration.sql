-- AlterTable
ALTER TABLE `utente` ADD COLUMN `cargo` VARCHAR(191) NULL,
    ADD COLUMN `departamento` VARCHAR(191) NULL;
