/*
  Warnings:

  - You are about to alter the column `tipoPeriodo` on the `configuracaomonitorizacao` table. The data in that column could be lost. The data in that column will be cast from `Enum(EnumId(0))` to `VarChar(191)`.
  - You are about to drop the column `chefeId` on the `monitorizacao` table. All the data in the column will be lost.
  - You are about to drop the column `dataSubmissao` on the `monitorizacao` table. All the data in the column will be lost.
  - You are about to drop the column `direcaoId` on the `monitorizacao` table. All the data in the column will be lost.
  - You are about to drop the column `numeroProcesso` on the `monitorizacao` table. All the data in the column will be lost.
  - You are about to drop the column `observacoes` on the `monitorizacao` table. All the data in the column will be lost.
  - You are about to drop the column `rupeDocumentoPath` on the `monitorizacao` table. All the data in the column will be lost.
  - You are about to drop the column `rupeValidado` on the `monitorizacao` table. All the data in the column will be lost.
  - You are about to drop the column `tecnicoId` on the `monitorizacao` table. All the data in the column will be lost.
  - You are about to alter the column `estado` on the `periodomonitorizacao` table. The data in that column could be lost. The data in that column will be cast from `Enum(EnumId(1))` to `VarChar(191)`.
  - Added the required column `updatedAt` to the `monitorizacao` table without a default value. This is not possible if the table is not empty.
  - Made the column `periodoId` on table `monitorizacao` required. This step will fail if there are existing NULL values in that column.

*/
-- DropForeignKey
ALTER TABLE `configuracaomonitorizacao` DROP FOREIGN KEY `ConfiguracaoMonitorizacao_utenteId_fkey`;

-- DropForeignKey
ALTER TABLE `monitorizacao` DROP FOREIGN KEY `Monitorizacao_periodoId_fkey`;

-- DropForeignKey
ALTER TABLE `monitorizacao` DROP FOREIGN KEY `Monitorizacao_utenteId_fkey`;

-- DropForeignKey
ALTER TABLE `periodomonitorizacao` DROP FOREIGN KEY `PeriodoMonitorizacao_configuracaoId_fkey`;

-- DropIndex
DROP INDEX `Monitorizacao_numeroProcesso_key` ON `monitorizacao`;

-- AlterTable
ALTER TABLE `configuracaomonitorizacao` MODIFY `tipoPeriodo` VARCHAR(191) NOT NULL;

-- AlterTable
ALTER TABLE `monitorizacao` DROP COLUMN `chefeId`,
    DROP COLUMN `dataSubmissao`,
    DROP COLUMN `direcaoId`,
    DROP COLUMN `numeroProcesso`,
    DROP COLUMN `observacoes`,
    DROP COLUMN `rupeDocumentoPath`,
    DROP COLUMN `rupeValidado`,
    DROP COLUMN `tecnicoId`,
    ADD COLUMN `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    ADD COLUMN `documentoFinalPath` VARCHAR(191) NULL,
    ADD COLUMN `estadoProcesso` VARCHAR(191) NOT NULL DEFAULT 'AGUARDANDO_PARECER',
    ADD COLUMN `rupePath` VARCHAR(191) NULL,
    ADD COLUMN `updatedAt` DATETIME(3) NOT NULL,
    MODIFY `periodoId` INTEGER NOT NULL,
    ALTER COLUMN `estado` DROP DEFAULT;

-- AlterTable
ALTER TABLE `periodomonitorizacao` MODIFY `estado` VARCHAR(191) NOT NULL;

-- AddForeignKey
ALTER TABLE `monitorizacao` ADD CONSTRAINT `monitorizacao_periodoId_fkey` FOREIGN KEY (`periodoId`) REFERENCES `periodomonitorizacao`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `monitorizacao` ADD CONSTRAINT `monitorizacao_utenteId_fkey` FOREIGN KEY (`utenteId`) REFERENCES `utente`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `configuracaomonitorizacao` ADD CONSTRAINT `configuracaoMonitorizacao_utenteId_fkey` FOREIGN KEY (`utenteId`) REFERENCES `utente`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `periodomonitorizacao` ADD CONSTRAINT `periodoMonitorizacao_configuracaoId_fkey` FOREIGN KEY (`configuracaoId`) REFERENCES `configuracaomonitorizacao`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
