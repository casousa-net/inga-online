-- AlterTable
ALTER TABLE `periodomonitorizacao` MODIFY `estado` VARCHAR(191) NOT NULL DEFAULT 'ABERTO';
