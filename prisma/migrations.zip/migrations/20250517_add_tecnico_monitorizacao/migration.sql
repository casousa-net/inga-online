-- Adicionar tabela para técnicos de monitorização
CREATE TABLE `tecnicomonitorizacao` (
  `id` INTEGER NOT NULL AUTO_INCREMENT,
  `monitorizacaoId` INTEGER NOT NULL,
  `tecnicoId` INTEGER NOT NULL,
  `createdAt` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  
  PRIMARY KEY (`id`),
  INDEX `tecnicomonitorizacao_monitorizacaoId_idx` (`monitorizacaoId`),
  INDEX `tecnicomonitorizacao_tecnicoId_idx` (`tecnicoId`),
  CONSTRAINT `tecnicomonitorizacao_monitorizacaoId_fkey` FOREIGN KEY (`monitorizacaoId`) REFERENCES `monitorizacao` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `tecnicomonitorizacao_tecnicoId_fkey` FOREIGN KEY (`tecnicoId`) REFERENCES `utente` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
);

-- Adicionar campos para visita técnica na tabela de monitorização
ALTER TABLE `monitorizacao` 
ADD COLUMN `dataPrevistaVisita` DATETIME(3) NULL,
ADD COLUMN `dataVisita` DATETIME(3) NULL,
ADD COLUMN `observacoesVisita` TEXT NULL;
