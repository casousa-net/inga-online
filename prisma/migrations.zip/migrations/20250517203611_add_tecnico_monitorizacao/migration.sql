-- DropForeignKey
ALTER TABLE `tecnicomonitorizacao` DROP FOREIGN KEY `TecnicoMonitorizacao_monitorizacaoId_fkey`;

-- DropForeignKey
ALTER TABLE `tecnicomonitorizacao` DROP FOREIGN KEY `TecnicoMonitorizacao_tecnicoId_fkey`;

-- AlterTable
ALTER TABLE `monitorizacao` MODIFY `observacoesVisita` VARCHAR(191) NULL;

-- AddForeignKey
ALTER TABLE `tecnicomonitorizacao` ADD CONSTRAINT `tecnicomonitorizacao_monitorizacaoId_fkey` FOREIGN KEY (`monitorizacaoId`) REFERENCES `monitorizacao`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `tecnicomonitorizacao` ADD CONSTRAINT `tecnicomonitorizacao_tecnicoId_fkey` FOREIGN KEY (`tecnicoId`) REFERENCES `utente`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;

-- RedefineIndex
CREATE INDEX `tecnicomonitorizacao_monitorizacaoId_idx` ON `tecnicomonitorizacao`(`monitorizacaoId`);
DROP INDEX `TecnicoMonitorizacao_monitorizacaoId_idx` ON `tecnicomonitorizacao`;

-- RedefineIndex
CREATE INDEX `tecnicomonitorizacao_tecnicoId_idx` ON `tecnicomonitorizacao`(`tecnicoId`);
DROP INDEX `TecnicoMonitorizacao_tecnicoId_idx` ON `tecnicomonitorizacao`;
